import {NextResponse} from "next/server";
import {createClient as createServerClient} from "@supabase/supabase-js";
import {createServerClient as createSSRClient} from "@supabase/ssr";
import {cookies} from "next/headers";

export async function POST(req:Request){
 try{
  const jar=await cookies();
  const session=createSSRClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{cookies:{getAll:()=>jar.getAll(),setAll:()=>{}}});
  const {data:{user}}=await session.auth.getUser();
  if(!user)return NextResponse.json({error:"سجّل الدخول أولاً"},{status:401});
  const admin=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:profile}=await admin.from("profiles").select("role").eq("id",user.id).single();
  if(profile?.role!=="teacher")return NextResponse.json({error:"هذه العملية للأستاذ فقط"},{status:403});
  const b=await req.json(); const full_name=String(b.full_name||"").trim(),grade_level=String(b.grade_level||""),email=String(b.email||"").trim(),password=String(b.password||"");
  if(!full_name||!email||password.length<8)return NextResponse.json({error:"أدخل الاسم والبريد وكلمة مرور من 8 أحرف على الأقل"},{status:400});
  const {data:created,error:e}=await admin.auth.admin.createUser({email,password,email_confirm:true});
  if(e||!created.user)return NextResponse.json({error:e?.message||"تعذر إنشاء الحساب"},{status:400});
  const {error:pe}=await admin.from("profiles").insert({id:created.user.id,full_name,role:"student"});
  if(pe){await admin.auth.admin.deleteUser(created.user.id);return NextResponse.json({error:pe.message},{status:400});}
  const student_code="STD-"+created.user.id.slice(0,6).toUpperCase();
  const {error:se}=await admin.from("students").insert({teacher_id:user.id,user_id:created.user.id,full_name,grade_level,student_code});
  if(se){await admin.from("profiles").delete().eq("id",created.user.id);await admin.auth.admin.deleteUser(created.user.id);return NextResponse.json({error:se.message},{status:400});}
  return NextResponse.json({ok:true,student_code});
 }catch(e){return NextResponse.json({error:"حدث خطأ أثناء إنشاء حساب التلميذ"},{status:500});}
}